package strings;
import java.util.Scanner;
public class ChangeCaseMethod{ 
    
   /* // Method to convert characters  
    // of a string to opposite case 
    static void convertOpposite(StringBuffer str) 
    { 
    	Scanner scanner=new Scanner(System.in);
    	String str1=scanner.next();
       int ln = str.length(); 
            
       // Conversion using predefined methods 
       for (int i=0; i<ln; i++) 
       { 
           Character c = str.charAt(i); 
           if (Character.isLowerCase(c)) 
               str.replace(i, i+1, Character.toUpperCase(c)+""); 
           else
               str.replace(i, i+1, Character.toLowerCase(c)+""); 
            
       } 
    } 
      
    public static void main(String[] args)  
    { 
        StringBuffer str = new StringBuffer(); 
        // Calling the Method 
        convertOpposite(str); 
          
        System.out.println(str); 
       } */
	public static void main(String args[]) {
		Scanner scanner=new Scanner(System.in);
		String output=scanner.next();
		getString(output);
		//System.out.println(getString(output));
	}
	public static String getString(String organization) {
		String str="";
		for(int i=0;i<organization.length();i++){
			str+=str.toUpperCase();
		}
		return str;
		
	}
} 
