package strings;
import java.util.Scanner;
public class CharIncrement {
	public static void main(String args[]) {
		Scanner scanner=new Scanner(System.in);
		String str=scanner.next();
		String strIncremented=new String();
		for(int i=0;i<str.length();i++){
			strIncremented+=(char)(str.charAt(i)+1);
		}
		System.out.println(strIncremented);
	}
	public static String getString(String organization) {
		return organization;	
	}
	
}
