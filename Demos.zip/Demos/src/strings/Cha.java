package strings;
import java.util.Scanner;
public class Cha {
	public static void main(String args[]) {
		Scanner scanner=new Scanner(System.in);
		String output=scanner.next();
		System.out.println(getString(output));
	}
	public static String getString(String organization) {
		String str="";
		for(int i=0;i<organization.length();i++){
			str+=(char)(organization.charAt(i)+1);
		}
		return str;	
	}
	
}


