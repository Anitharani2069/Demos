package exampleofstream;
/*String maxChar = Stream.of("H", "T", "D", "I", "J")
                        .max(Comparator.comparing(String::valueOf))
                        .get();
 
String minChar = Stream.of("H", "T", "D", "I", "J")
                        .min(Comparator.comparing(String::valueOf))
                        .get();
 
System.out.println("maxChar = " + maxChar);
System.out.println("minChar = " + minChar);*/