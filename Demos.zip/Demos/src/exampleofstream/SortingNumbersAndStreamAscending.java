package exampleofstream;
import java.util.stream.Stream;
 
public class SortingNumbersAndStreamAscending
{
    public static void main(String[] args)
    {
        Stream<Integer> numStream = Stream.of(1,3,5,4,2);
         
        numStream.sorted()
                 .forEach(System.out::println);
    }
}