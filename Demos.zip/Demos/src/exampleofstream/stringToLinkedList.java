package exampleofstream;
import java.util.Arrays;
import java.util.LinkedList;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;
 
public class stringToLinkedList
{
    public static void main(String[] args)
    {  
        Stream<String> tokenStream = Arrays.asList("A", "B", "C", "D").stream();  //stream
         
        List<String> tokenlist = tokenStream.collect(Collectors.toCollection(LinkedList::new));   //list
 
        System.out.println(tokenlist); 
    }
}