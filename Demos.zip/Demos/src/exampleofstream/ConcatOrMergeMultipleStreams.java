package exampleofstream;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import static java.util.stream.Stream.*;
 
public class ConcatOrMergeMultipleStreams
{
    public static void main(String[] args)
    {
        Stream<Integer> first = Stream.of(1, 2);
        Stream<Integer> second = Stream.of(3,4);
        Stream<Integer> third = Stream.of(5, 6);
        Stream<Integer> fourth = Stream.of(7,8);
         
        Stream<Integer> resultingStream = Stream.concat(first, concat(second, concat(third, fourth)));
         
        System.out.println( resultingStream.collect(Collectors.toList()) );
    }
}