package exampleofstream;
/*List<Integer> ints = IntStream.of(1,2,3,4,5)
                .boxed()
                .collect(Collectors.toList());
         
System.out.println(ints);
 
Output:
 
[1, 2, 3, 4, 5]*/