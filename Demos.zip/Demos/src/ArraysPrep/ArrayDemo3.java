package ArraysPrep;

public class ArrayDemo3 {
public static void main(String args[]){
	long a[]=new long[]{1l,2l,3l,4l,5l};
	
	for(long i:a)
		System.out.print(i+" ");
	System.out.println("\n");
	
	}
		
}

