package examplesFileHandling;
import java.io.*;

public class ReadfileUsingSpecificIndexOrskippingbyte
{
	public static void main(String[] args) 
	{
		//file class object     
		File file = new File("E:/JAVA/IncludeHelp.txt");
		try
		{
			FileInputStream fin = new FileInputStream(file);
			int ch;

			System.out.println("File's content after 10 bytes is: ");
			//skipping 10 bytes to read the file
			fin.skip(10);
			while( (ch = fin.read()) != -1 )
				System.out.print((char) ch);
		}
		catch(FileNotFoundException ex)
		{
			System.out.println("FileNotFoundException : " + ex.toString());
		}
		catch(IOException ioe)
		{
			System.out.println("IOException : " + ioe.toString());
		}
		catch (Exception e)
		{
			System.out.println("Exception: " + e.toString());
		}
	}
}
