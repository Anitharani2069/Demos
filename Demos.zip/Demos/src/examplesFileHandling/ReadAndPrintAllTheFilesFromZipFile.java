package examplesFileHandling;
import java.io.BufferedInputStream;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

public class ReadAndPrintAllTheFilesFromZipFile
{
	public void printFileList(String filePath)
	{
		// initializing the objects.
		FileInputStream fis = null;
		ZipInputStream Zis = null;
		ZipEntry zEntry = null;
		try 
		{
			fis = new FileInputStream(filePath);
			Zis = new ZipInputStream(new BufferedInputStream(fis));

			// this will search the files while end of the zip.
			while((zEntry = Zis.getNextEntry()) != null)
			{
				System.out.println(zEntry.getName());
			}
			Zis.close();
		} 
		catch (FileNotFoundException e) 
		{
			e.printStackTrace();
		} 
		catch (IOException e) 
		{
			e.printStackTrace();
		}
	}
	//main function
	public static void main(String a[])
	{
		// creating object of the file.
		ReadAndPrintAllTheFilesFromZipFile fff = new  ReadAndPrintAllTheFilesFromZipFile();
		System.out.println("Files in the Zip are : ");

		// enter the path of the zip file with name.
		fff.printFileList("D:/JAVA.zip");
	}
}