package examplesFileHandling;
import java.io.*;

public class Determinenumberofbyteswrittentofileusingdataoutputstream
{
	//Java program to determine number of bytes written to file using DataOutputStream
	public static void main(String[] args){
		try
		{
		    FileOutputStream objFOS = new FileOutputStream("E:/includehelp.txt");
		    DataOutputStream objDOS = new DataOutputStream(objFOS);

		    objDOS.writeBytes("IncludeHelp is for computer science students.");
		    int bytesWritten = objDOS.size();
		    System.out.println("Total " + bytesWritten + " bytes are written to stream.");
		    objDOS.close();			
		}
		catch(Exception ex)
		{
			System.out.println("Exception: " + ex.toString());
		}

	  }
}