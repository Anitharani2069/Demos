package examplesFileHandling;
import java.io.*;

public class CheckFileHiddenornot 
{
  public static void main(String[] args) 
  {  // enter the file name here.
	 // create file object.
     File file = new File("E:/includehelp.txt");
     
     // this will check is the file hidden or not.
     boolean blnHidden = file.isHidden();
     
     // return result in true or false condition.
     System.out.println("Is the file " + file.getPath() + " hidden ?: " + blnHidden);
  }
}