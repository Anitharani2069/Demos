package BufferAndBuilder;
public class CopyingOfArray {
 
    public static void main(String []args) {
        int arrcopy_from[] = {5,10,15,20,25,30,35,40,45}; //Copy from or source array
        int arrcopy_to[] = new int[6]; //Destination array                           
        System.arraycopy(arrcopy_from, 1, arrcopy_to, 0, 6);  //This is where elements will be copied
        //Printing copied array elements
 
 
 
        System.out.println("The array elements after copying:" + " ");
 
        for (int i=0;i<arrcopy_to.length;i++){
 
 
 
                 System.out.println(arrcopy_to[i]);
              }
 
 }    
 
}