package junitexamples;
/*package junitexamples;
 
import org.junit.Test;
import static org.junit.Assert.*;
 
public class AssertFalse {
 
    public boolean isEvenNumber(int number){
         
        boolean result = false;
        if(number%2 == 0){
            result = true;
        }
        return result;
    }
     
    @Test
    public void evenNumberTest(){
        AssertFalse asft = new AssertFalse();
        assertFalse(asft.isEvenNumber(3));
    }
}*/