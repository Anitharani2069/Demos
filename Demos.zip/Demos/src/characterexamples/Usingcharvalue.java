package characterexamples;
import java.lang.*; 
  
/*public class Usingcharvalue { 
  
    public static void main(String[] args) 
    { 
        // Create a character object 
        Character x = new Character('z'); 
  
        // assign the primitive value to a character 
        char ch = x.charValue(); 
  
        System.out.println("Primitive char value is " + ch); 
    } 
} 

import java.lang.*; */

public class Usingcharvalue { 
  
    public static void main(String[] args) 
    { 
        // create a Character object x 
        Character x = new Character('9'); 
  
        // assign value is a number 
        // assign the primitive value to a character 
        char ch = x.charValue(); 
  
  
        // print the primitive char value 
        System.out.println("Primitive char value is " + ch); 
    } 
} 