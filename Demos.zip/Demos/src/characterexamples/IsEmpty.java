package characterexamples;
class C6{
  public static void main(String[] args){
    String s1 = "Umbrella";
    String s2 = "";
    System.out.println(s1.isEmpty());
    System.out.println(s2.isEmpty());
  }
}