package characterexamples;
import java.util.Scanner;
 
public class CharacterExistsOrNot {
 
    public static void main(String []args) {
 
 
 
       Scanner readInput = new Scanner(System.in);  // Reading from System.in
 
                 System.out.println("Enter a String: ");
 
                 String str_charAt = readInput.next();
 
 
 
                 char chr = str_charAt.charAt(0);
 
                 if (chr == 'a' || chr == 'e' || chr == 'i' || chr == 'o' || chr == 'u')
 
                   System.out.println("Found the following vowel as first character: " +chr);
 
 }    
 
}