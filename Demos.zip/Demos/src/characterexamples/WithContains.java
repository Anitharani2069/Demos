package characterexamples;
class C12{
  public static void main(String[] args){
    String s1 = "My name is : Robert Brown";
    System.out.println(s1.contains("Robe"));
    System.out.println(s1.contains(":"));
    System.out.println(s1.contains("/"));
  }
}