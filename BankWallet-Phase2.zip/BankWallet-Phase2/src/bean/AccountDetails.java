package bean;

public class AccountDetails {
	CustomerDetails c;
	private int accNo;
	private String accType;
	private double balance;
	static int count = 1;
	public AccountDetails(CustomerDetails c) {
		super();
		this.c = c;
		this.accNo = 41503982+count;
		this.accType = c.getAccType();
		this.balance = 0.0;
		count++;
	}
	
	public AccountDetails(){
		
	}

	public CustomerDetails getC() {
		return c;
	}

	public void setC(CustomerDetails c) {
		this.c = c;
	}

	public String getAccType() {
		return accType;
	}

	public void setAccType(String accType) {
		this.accType = accType;
	}

	public double getBalance() {
		return balance;
	}

	public void setBalance(double balance) {
		this.balance = balance;
	}

	public int getAccNo() {
		return accNo;
	}

	@Override
	public String toString() {
		return "AccountDetails[c=" + c + ", accNo=" + accNo + ", accType=" + accType + ", balance=" + balance + "]";
	}

	
	
	
	

}
