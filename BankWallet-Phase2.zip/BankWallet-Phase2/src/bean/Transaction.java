package bean;



	public class Transaction {
		private int tid;
		private String TransType ;
		double amount;
		static int i = 0;
		
		public Transaction( String transType, double amount) {
			
			this.tid = i;
			TransType = transType;
			this.amount = amount;
			i++;
		}
		
		public Transaction(){
			
		}

		public int getTid() {
			return tid;
		}

		public void setTid(int tid) {
			this.tid = tid;
		}

		public String getTransType() {
			return TransType;
		}

		public void setTransType(String transType) {
			TransType = transType;
		}

		public double getAmount() {
			return amount;
		}

		public void setAmount(double amount) {
			this.amount = amount;
		}

		public static int getI() {
			return i;
		}

		public static void setI(int i) {
			Transaction.i = i;
		}

		@Override
		public String toString() {
			return "Transaction [tid=" + tid + ", TransType=" + TransType + ", amount=" + amount + "]";
		}
		
		
		
		
	}

