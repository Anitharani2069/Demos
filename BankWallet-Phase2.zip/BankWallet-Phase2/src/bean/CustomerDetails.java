package bean;

public class CustomerDetails {
	
	
	private String custName;
	private String emailId;
	private String phoneNo;
	//private long bankAccNo;
	String accType;
	
	public CustomerDetails( String custName, String emailId, String phoneNo, String accType) {
	
		this.custName = custName;
		this.emailId = emailId;
		this.phoneNo = phoneNo;
		this.accType = accType;
	}
	
	public CustomerDetails(){
		
	}

	public String getCustName() {
		return custName;
	}

	public void setCustName(String custName) {
		this.custName = custName;
	}

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public String getPhoneNo() {
		return phoneNo;
	}

	public void setPhoneNo(String phoneNo) {
		this.phoneNo = phoneNo;
	}

	public String getAccType() {
		return accType;
	}

	public void setAccType(String accType) {
		this.accType = accType;
	}

	@Override
	public String toString() {
		return "CustomerDetails [custName=" + custName + ", emailId=" + emailId + ", phoneNo=" + phoneNo + ", accType="
				+ accType + "]";
	}
	
	
	
	
	
	

}
