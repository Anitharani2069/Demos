package ui;

import java.util.List;

import java.util.Scanner;

import bean.AccountDetails;
import bean.CustomerDetails;
import bean.Transaction;
import service.BankService;

public class Main {
	static Scanner sc = new Scanner(System.in);
	static BankService bs = new BankService();
	
	private static void showTransaction() {
		System.out.println("Enter your account no");
		int i = sc.nextInt();
		List<Transaction> lobj = bs.getTransactionService(i);
		System.out.println(lobj);
	}

	private static void transferMoney() {
		System.out.println("Enter your account no");
		int i = sc.nextInt();
		System.out.println("Enter the account no that you want to transfer");
		int j = sc.nextInt();
		System.out.println("Enter amount you want to transfer");
		double amt = sc.nextDouble();
		AccountDetails b1 =  bs.printDetails(i);
		AccountDetails b2 =  bs.printDetails(j);
		bs.transferAmount(b1, b2, amt);
		System.out.println("amount successfully transfered");
		Transaction t = new Transaction("Fund Transfer",amt);
		Transaction t1 = new Transaction("Fund Transfer",amt);
		//Transaction t = new Transaction(bo.getAccType(),amt);
	//	bs.storeTransactionService(b1.getAccNo(),t);
		//bs.storeTransactionService(b2.getAccNo(),t1);
	}

	private static void withdrawMoney() {
		System.out.println("Enter account no");
		int i = sc.nextInt();
		System.out.println("Enter amount you want to withdraw");
		double amt = sc.nextDouble();
		AccountDetails bo =  bs.printDetails(i);
		boolean flag = bs.updateWithdrawBalance(bo,amt);
		if(!flag) {
			System.out.println("Insufficient balance to withdraw");
		}
		else {
		System.out.println("Successfully withdraw the amount");
		Transaction t = new Transaction("Withdrawl",amt);
		bs.addTransaction(t);

		//bs.storeTransactionService(bo.getAccNo(),t);
	}
	}

	private static void depositMoney() {
		System.out.println("Enter account no");
		int i = sc.nextInt();
		System.out.println("Enter amount you want to deposit");
		double amt = sc.nextDouble();
		AccountDetails bo =  bs.printDetails(i);
		bs.updateDepositBalance(bo,amt);
		System.out.println("Successfully deposited the amount");
		Transaction t = new Transaction("Deposited",amt);
		bs.addTransaction(t);
		//bs.storeTransactionService(bo.getAccNo(),t);
		
		
	}

	private static void showBalance() {
		System.out.println("Enter account no");
		int i = sc.nextInt();
		AccountDetails bo =  bs.printDetails(i);
		System.out.println(bo);
	}

	private static AccountDetails createAccount() {
		System.out.println("Enter your name");
		String name = sc.next();
		System.out.println("Enter your email id");
	    String emailId = sc.next();
	    System.out.println("Enter your phone no.");
		String phoneNo = sc.next();
		System.out.println("Enter bank account type as : Savings or Current");
		//private long bankAccNo;
		String accType = sc.next();
		CustomerDetails c1 = new CustomerDetails(name,emailId,phoneNo,accType);
		System.out.println(c1);
		bs.addCustomer(c1);
		AccountDetails b1 = new AccountDetails(c1);
		System.out.println("Account successfully created");
		//System.out.println(b1);
		return b1;
	}

	
	public static void main(String[] args) {
		String ch="";
		do{
		System.out.println("Welcome to Bank of People");
		System.out.println("Enter your choice\n1.Create New Account\n2.Show Balance\n3.Deposit Money\n"
				+ "4.Withdraw Money\n5.Fund Transfer\n6.Print Transaction");
		int choice = sc.nextInt();
		switch(choice){
		case 1: AccountDetails bobj1 = createAccount();
		System.out.println("Object created");
				//bs.storeDetails(bobj1);
				bs.addAccount(bobj1);
			
				System.out.println(bobj1.getAccNo());
				
				break;
		case 2: showBalance();
				break;
		case 3:	depositMoney();
				break;
		case 4:	withdrawMoney();
				break;
		case 5: transferMoney();
				break;
		case 6: showTransaction();
				break;
		default : System.out.println("Invalid choice. Enter correct choice!!!");
		}
		
		System.out.println("do you want to continue?\n enter YES OR NO");
			   
			   ch = sc.next();
			   
			   }
			   while(ch.equalsIgnoreCase("yes"));
		System.exit(0);
	}

	
}
