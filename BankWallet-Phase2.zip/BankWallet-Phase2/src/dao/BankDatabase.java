package dao;

import java.util.ArrayList;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import bean.AccountDetails;

public class BankDatabase {
		static Map<Integer,AccountDetails> mobj = new HashMap<Integer,AccountDetails>();
		static AccountDetails b;
		
		public void storeDetailsdao(AccountDetails b){
			mobj.put(b.getAccNo(),b);
		}
		
		public Map<Integer,AccountDetails> displayDetailsdao(int i){
			Set<Integer> s = mobj.keySet();
			boolean flag = false;
			for(Integer j:s){
				if(i==j){
					 flag = true; 
					break;
				//	return bnew;
				}
				else{
					continue;
			}}
				if(flag){
					return mobj;
				}
				else{
				return null;
				}
		
		
}}
