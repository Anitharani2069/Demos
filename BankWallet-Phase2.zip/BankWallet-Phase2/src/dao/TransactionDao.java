package dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import bean.Transaction;
import dbutil.DbConnection;

public class TransactionDao {

	
	public void addTransactionDao(Transaction t){
	//	int res = 0;
		try {
			DbConnection db = new DbConnection();
			Connection conn = db.getConn();
System.out.println("Inside custdb");
			String query = "insert into transactiondb values(?,?,?)";
			PreparedStatement pstmt = conn.prepareStatement(query);
			pstmt.setInt(1, t.getTid());
			
			pstmt.setString(2, t.getTransType());
			pstmt.setDouble(3, t.getAmount());
		
			
			pstmt.executeUpdate();
			
			 
					conn.close();
			
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		//System.out.println(res);
		
	}
}
