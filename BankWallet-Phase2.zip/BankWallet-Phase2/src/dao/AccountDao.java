package dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import bean.AccountDetails;
import dbutil.DbConnection;

public class AccountDao {

	
	public void addEmployeeDao(AccountDetails a){
	//	int res = 0;
		try {
			DbConnection db = new DbConnection();
			Connection conn = db.getConn();
System.out.println("Inside Db");
			String query = "insert into accounts values(?,?,?)";
			PreparedStatement pstmt = conn.prepareStatement(query);
			pstmt.setInt(1, a.getAccNo());
			
			pstmt.setString(2, a.getAccType());
			pstmt.setDouble(3, a.getBalance());
			
			pstmt.executeUpdate();
			
			 
					conn.close();
			
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		//System.out.println(res);
		
	}
}
