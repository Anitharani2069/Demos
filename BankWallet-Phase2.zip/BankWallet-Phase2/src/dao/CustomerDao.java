package dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import bean.CustomerDetails;
import dbutil.DbConnection;

public class CustomerDao {

	
	public void addCustomerDao(CustomerDetails c){
	//	int res = 0;
		try {
			DbConnection db = new DbConnection();
			Connection conn = db.getConn();
System.out.println("Inside custdb");
			String query = "insert into customer values(?,?,?,?)";
			PreparedStatement pstmt = conn.prepareStatement(query);
			pstmt.setString(1, c.getCustName());
			
			pstmt.setString(2, c.getEmailId());
			pstmt.setString(3, c.getPhoneNo());
			pstmt.setString(4, c.getAccType());
			
			pstmt.executeUpdate();
			
			 
					conn.close();
			
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		//System.out.println(res);
		
	}
}
