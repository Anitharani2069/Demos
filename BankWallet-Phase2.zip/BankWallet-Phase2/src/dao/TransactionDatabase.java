package dao;
 
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import bean.Transaction;

public class TransactionDatabase {

	 Map<Integer,List<Transaction>> tdb = new HashMap<Integer,List<Transaction>>();
	 
	
	public void storeTransaction(int acctNo,Transaction tr){
		if(tdb.containsKey(acctNo)) {
			
			List<Transaction> list2 = tdb.get(acctNo);
			list2.add(tr);
			tdb.replace(acctNo, tdb.get(acctNo), list2);
			
		}
		else {
			List<Transaction> trdb = new ArrayList<Transaction>(); 
		//	tr.setTid(0);
			trdb.add(tr);
			tdb.put(acctNo, trdb);
		}
		
		//System.out.println(tdb);
	}
	
	public Map<Integer,List<Transaction>> getTransactiondao(int acctNo){
		
		Set<Integer> s = tdb.keySet();
		boolean flag = false;
		for(Integer j:s){
			if(acctNo==j){
				 flag = true; 
				break;
			//	return bnew;
			}
			else{
				continue;
		}}
			if(flag){
				return tdb;
			}
			else{
			return null;
			}
	}
	
}
