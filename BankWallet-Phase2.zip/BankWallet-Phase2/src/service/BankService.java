package service;

import java.util.List;

import java.util.Map;
import java.util.Set;

import bean.AccountDetails;
import bean.CustomerDetails;
import bean.Transaction;
import dao.AccountDao;
import dao.BankDatabase;
import dao.CustomerDao;
import dao.TransactionDao;
import dao.TransactionDatabase;



public class BankService implements BankServiceIntf{
	BankDatabase bdao = new BankDatabase();
	TransactionDatabase tdao = new TransactionDatabase();
	AccountDao adao = new AccountDao();
	CustomerDao cdao =  new CustomerDao();
	TransactionDao trdao = new TransactionDao();
	
	@Override
	public void storeDetails(AccountDetails b) {
		bdao.storeDetailsdao(b);
	}
	

	public AccountDetails printDetails(int accNo) {
		Map<Integer,AccountDetails> servicemap = bdao.displayDetailsdao(accNo);
		AccountDetails bobj = null;
		//boolean flag = false;
		Set<Integer> s = servicemap.keySet();
		for(Integer a:s){
			if(a==accNo){
				bobj = servicemap.get(a);
			//	flag = true;
				break;
			}
			else{
			//	flag = false;
				continue;
			}
		}
		return bobj;
		
		
	}


	@Override
	public void updateDepositBalance(AccountDetails b,double amt) {
		b.setBalance(b.getBalance()+amt);
		
	}
	
	public boolean updateWithdrawBalance(AccountDetails b,double amt){
		double balance = b.getBalance();
		if(balance < amt) {
			return false;
		}
		else {
			b.setBalance(b.getBalance()-amt);
			return true;
		}
	
}


	@Override
	public void transferAmount(AccountDetails b1, AccountDetails b2, double amt) {
		b1.setBalance(b1.getBalance()-amt);
		b2.setBalance(b2.getBalance()+amt);
		
	}
	
	public void storeTransactionService(int id,Transaction t){
		tdao.storeTransaction(id,t);
	}
	
	
	public List<Transaction> getTransactionService(int acctNo){
	Map<Integer,List<Transaction>> m = tdao.getTransactiondao(acctNo);
	List<Transaction> tobj = null;
	//boolean flag = false;
	Set<Integer> s = m.keySet();
	for(Integer a:s){
		if(a == acctNo){
			tobj = m.get(a);
		//	flag = true;
			break;
		}
		else{
		//	flag = false;
			continue;
		}
	}
	return tobj;
	
	
	}


	@Override
	public void addAccount(AccountDetails a) {
		//System.out.println("inside servide");
		adao.addEmployeeDao(a);
	}


	@Override
	public void addCustomer(CustomerDetails c) {
	//	System.out.println("inside custser");
		cdao.addCustomerDao(c);
	}


	@Override
	public void addTransaction(Transaction t) {
		// TODO Auto-generated method stub
		trdao.addTransactionDao(t);
		
	}
	}