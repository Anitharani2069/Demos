package service;

import java.util.Map;

import bean.AccountDetails;
import bean.CustomerDetails;
import bean.Transaction;

public interface BankServiceIntf {
	
	void storeDetails(AccountDetails b);
	
	public AccountDetails printDetails(int accNo);
	
	public void updateDepositBalance(AccountDetails b,double amt);
	
	public boolean updateWithdrawBalance(AccountDetails b,double amt);
	
	public void transferAmount(AccountDetails b1,AccountDetails b2,double amt);
	
	public void addAccount(AccountDetails a);
	
	public void addCustomer(CustomerDetails c);
	
	public void addTransaction(Transaction t);

}
