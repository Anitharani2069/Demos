package ArraysPrep;

public class ArrayDemo1 {
public static void main(String args[]){
	int a[]=new int[2];
	a[0]=1;
	a[1]=2;
	
	System.out.println(a[0]);
	System.out.println(a[1]);
	int b[][]=new int[3][2];
	b[0][0]=1;
	b[0][1]=2;
	b[1][0]=3;
	b[1][1]=4;
	b[2][0]=5;
	b[2][1]=6;
	System.out.println(b[1][1]);
}
}

