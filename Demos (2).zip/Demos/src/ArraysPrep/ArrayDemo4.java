package ArraysPrep;

public class ArrayDemo4 {
public static void main(String args[]){
	int [][]b=new int[][]{{1,2},{2,3},{4,5}};
	for(int []i:b){
		for(int j:i)
			System.out.print(j+" ");
		System.out.println();
			
	}
}
}
