package exampleofstream;
/*List<Employee> employees = Stream.generate(Employee::create)
                            .limit(5)
                            .collect(Collectors.toList());
 
System.out.println(employees);*/