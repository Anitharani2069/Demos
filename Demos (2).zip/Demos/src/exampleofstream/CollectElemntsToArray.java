package exampleofstream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
 
public class CollectElemntsToArray
{
    public static void main(String[] args)
    {
       /* List<Employee> employeeList = new ArrayList<>(Arrays.asList(
                            new Employee(1, "A", 100),
                            new Employee(2, "B", 200),
                            new Employee(3, "C", 300),
                            new Employee(4, "D", 400),
                            new Employee(5, "E", 500),
                            new Employee(6, "F", 600)));
         
        Employee[] employeesArray = employeeList.stream()
                                    .filter(e -> e.getSalary() < 400)
                                    .toArray(Employee[]::new);
         
        System.out.println(Arrays.toString(employeesArray));*/
    }
}