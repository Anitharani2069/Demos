package exampleofstream;
/*Stream<String> wordStream = Stream.of("A","C","E","B","D");
 
wordStream.sorted()                                 //ascending
          .forEach(System.out::println);           
         
wordStream.sorted( Comparator.reverseOrder() )      //descending
          .forEach(System.out::println);*/