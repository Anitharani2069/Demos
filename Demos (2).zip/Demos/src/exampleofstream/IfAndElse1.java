package exampleofstream;
/*ArrayList<Integer> numberList = new ArrayList<>(Arrays.asList(1,2,3,4,5,6));
         
Consumer<Integer> action = i -> {
    if(i % 2 == 0) {
        System.out.println("Even number :: " + i);
    } else {
        System.out.println("Odd  number :: " + i);
    }
};
 
numberList.stream().forEach(action);*/