package BufferAndBuilder;
public class InsertUsingStringBuilder {
 
          public static void main(String args[]) {
 
                 StringBuilder s_builder_ins = new StringBuilder("Hello mutable string by StringBuilder. ");
 
                
 
                 System.out.println("Original String: " +s_builder_ins);
 
                 s_builder_ins.insert(24, "Java ");
 
                 System.out.println("After insert method: " +s_builder_ins);
 
     }
 
 
 
}