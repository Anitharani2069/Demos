package BufferAndBuilder;
public class RemoveUsingStringBuffer {
 
          public static void main(String args[]) {
 
                 StringBuffer sBuf = new StringBuffer("Hello mutable string by Java. ");
                 System.out.println("Original String: " +sBuf);
 
                 sBuf.delete(6,20);
 
                 System.out.println("After delete() method: " +sBuf);
 
     }
 
 
 
}