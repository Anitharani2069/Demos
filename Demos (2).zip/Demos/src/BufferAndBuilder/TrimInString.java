package BufferAndBuilder;
public class TrimInString {
 
    public static void main(String []args) {
 
       //A demo of using trim() method
 
        String str_trim = "   A string for trim demonstration   ";
 
       
 
        System.out.println(str_trim);
 
        System.out.println(str_trim.trim());
 
 
 
 }
 
}