package BufferAndBuilder;
public class splitMethod {
 
          public static void main(String args[]) {
 
                
 
                    String str_split = new String("The String split method");
 
                    System.out.println("The string after split :\n" );     
 
                   
 
                    //Using split method with a space regex
 
                    for (String str: str_split.split(" ")) {
 
                       System.out.println(str);
 
                    }
 
                 }
 
}

/*public class split_demo {
	 
    public static void main(String args[]) {

          

              String str_tel = "458-758-8975";

              System.out.println("The Phone after split with limit :\n" );     

             

              //Using split method with a dash regex

              for (String str: str_tel.split("-",2)) {

                 System.out.println(str);

              }

           }

}*/

/*public class split_demo {
	 
    public static void main(String args[]) {

          

              String str_split = new String("Sentense 1 in paragraph. Sentense 2 in paragraph. Sentense 3 in paragraph");

             

              //with a dot regex

              for (String str_dot: str_split.split("\\. ")) {

                 System.out.println(str_dot);

              }

           }

}*/