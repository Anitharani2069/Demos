package BufferAndBuilder;
public class AppendUsingStringBuilder {
 
          public static void main(String args[]) {
 
                 StringBuilder s_builder = new StringBuilder("Hello mutable string by StringBuilder. ");
 
                
 
                 System.out.println(s_builder);
 
                 s_builder.append("Another string added");
 
                 System.out.println(s_builder);
 
     }
 
 
 
}