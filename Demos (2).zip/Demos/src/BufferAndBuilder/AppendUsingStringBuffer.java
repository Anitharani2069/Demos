package BufferAndBuilder;
public class AppendUsingStringBuffer {
 
          public static void main(String args[]) {
 
                 StringBuffer s_buffer = new StringBuffer("Hello mutable string. ");
 
                
 
                 System.out.println(s_buffer);
 
                 s_buffer.append("Another string added");
 
                 System.out.println(s_buffer);
 
     }
 
 
 
}