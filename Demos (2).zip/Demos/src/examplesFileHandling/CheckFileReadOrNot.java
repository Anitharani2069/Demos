package examplesFileHandling;
import java.io.*;
public class CheckFileReadOrNot 
{
	public static void main(String[] args) 
	{
		String filePath = "E:/C.txt";
		File file = new File(filePath);
		if(file.canRead())
		{
			System.out.println("File " + file.getPath() +" can be read");
		}
		else
		{
			System.out.println("File " + file.getPath() +" can not be read");
		}
	}
}