package stringsExa;
/* Java Program Example - Copy String */

import java.util.Scanner;

public class CopyStr
{
   public static void main(String args[])
   {
      String strOrig;
      Scanner scan = new Scanner(System.in);
 
      System.out.print("Enter a String : ");
      strOrig = scan.nextLine();
      
      System.out.print("Copying String...\n");
      
      StringBuffer strCopy = new StringBuffer(strOrig);
      
      System.out.print("String Copied Successfully..!!\n");      
      System.out.print("The Copied String is " + strCopy);
   }
}