package stringsExa;
/* Java Program Example - Convert Uppercase String to Lowercase */

/*import java.util.Scanner;

public class StrUpperToLower
{
    public static void main(String[] input)
    {
        Scanner scan = new Scanner(System.in);
        
        System.out.print("Enter one word/name in Uppercase : ");
        String strUpper1 = scan.nextLine();
        StrUpperToLower lr=new StrUpperToLower();
        //System.out.println(getString(strUpper1));
        lr.getString(strUpper1);
    }
        public static String getString(String Lower) {
        	String strUpper = "";
        String strLower = strUpper.toLowerCase();
        System.out.print("Equivalent Word/Name in Lowercase : " + strLower);
		return strLower;
    }}*/
import java.util.Scanner;

public class StrUpperToLower
{
    public static void main(String[] input)
    {
        String strUpper, strLower;
        Scanner scan = new Scanner(System.in);
        
        System.out.print("Enter one word/name in Uppercase : ");
        strUpper = scan.nextLine();
        
        strLower = strUpper.toLowerCase();
        System.out.print("Equivalent Word/Name in Lowercase : " + strLower);
    }
}