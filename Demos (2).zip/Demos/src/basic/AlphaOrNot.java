package basic;
import java.util.Scanner;

/*public class AlphaOrNot
{
    public static void main(String args[])
    {
        char ch;
        Scanner scan = new Scanner(System.in);
		
        System.out.print("Enter a Character : ");
        ch = scan.next().charAt(0);
		
        if((ch>='a' && ch<='z') || (ch>='A' && ch<='Z'))
        {
            System.out.print(ch + " is an Alphabet");
        }
        else
        {
            System.out.print(ch + " is not an Alphabet");
        }
    }
}*/
public class AlphaOrNot
{
    public static void main(String args[])
    {
        Scanner scan = new Scanner(System.in);
		
        System.out.print("Enter a Character : ");
       char ch1 = scan.next().charAt(0);
       AlphaOrNot an=new AlphaOrNot();
       //System.out.println(getChar(ch1));
       an.getChar(ch1);
    }
    public static void getChar(Character ch) {
        if((ch>='a' && ch<='z') || (ch>='A' && ch<='Z'))
        {
            System.out.print(ch + " is an Alphabet");
        }
        else
        {
            System.out.print(ch + " is not an Alphabet");
        }
    }
    }