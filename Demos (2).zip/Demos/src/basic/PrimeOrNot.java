package basic;
import java.util.Scanner;

public class PrimeOrNot
{
    public static void main(String args[])
    {
        Scanner scan = new Scanner(System.in);
        System.out.print("Enter a Number : ");
        int num = scan.nextInt();
        PrimeOrNot pn=new PrimeOrNot();
        System.out.println(getPrime(num));
        
    }
    public static int getPrime(int num) {
    	int count=0;
        for(int i=2; i<num; i++)
        {
            if(num%i == 0)
            {
                count++;
                break;
            }
        }
        if(count == 0)
        {
            System.out.print("This is a Prime Number");
        }
        else
        {
            System.out.print("This is not a Prime Number");
        }
		return 0;

		}
    }