package strings;
import java.util.Scanner;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class MaximumAmongList {

	public static void main(String[] args) {

		// your logic here
		List<String> list=new ArrayList<String>();
		System.out.println(getnames(list));
		
	}

	public static String getnames(List<String> names) {

		names=new ArrayList<String>();
		Scanner in=new Scanner(System.in);
		int n=in.nextInt();
		for(int i=0;i<n;i++) {
		String a=in.next();
		names.add(a);
		}
		String str=Collections.max(names);
		//System.out.println(str);
		return str;
	}

}
